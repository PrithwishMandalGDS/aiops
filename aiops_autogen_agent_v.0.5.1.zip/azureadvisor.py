import os
import json
import csv
import chromadb
import autogen
from autogen.agentchat.contrib.vectordb.chromadb import ChromaVectorDB
from autogen import config_list_from_json, Cache
from chromadb.utils import embedding_functions
from autogen.agentchat.contrib.retrieve_user_proxy_agent import RetrieveUserProxyAgent
from autogen.agentchat.contrib.retrieve_assistant_agent import RetrieveAssistantAgent
from autogen import AssistantAgent
from azure.identity import DefaultAzureCredential
from azure.mgmt.monitor import MonitorManagementClient
from azure.mgmt.advisor import AdvisorManagementClient
import processinglibrary
import prompts.complexityprompt
import prompts.movegroupprompt
import prompts.rlaneprompt
import prompts.servermappingprompt
import prompts.surveyresponseprompt

credential = DefaultAzureCredential()
subscription_id = '200c7489-b327-42c4-b931-85c9259878ae'

def list_resource_health(subscription_id):
    health_list = []
    try:
        monitor_client = MonitorManagementClient(credential, subscription_id)
        
        for health in monitor_client.resource_health_metadata.list_by_subscription_id():
            health_list.append(health.as_dict())
    except Exception as e:
        print(f"An error occurred while retrieving resource health: {e}")
    return health_list


def list_advisor_recommendations(subscription_id):
    recommendations_list = []
    try:
        advisor_client = AdvisorManagementClient(credential, subscription_id)
        
        for recommendation in advisor_client.recommendations.list():
            recommendations_list.append(recommendation.as_dict())
    except Exception as e:
        print(f"An error occurred while retrieving Azure Advisor recommendations: {e}")
    return recommendations_list


def save_to_csv(data, filename):
    try:
        # Ensure the data is not empty
        if len(data) > 0:
            # Open the CSV file for writing
            with open(filename, 'w', newline='') as f:
                # Create a CSV writer
                writer = csv.DictWriter(f, fieldnames=data[0].keys())
                
                # Write the header
                writer.writeheader()
                
                # Write the data rows
                writer.writerows(data)
            
            print(f"Data successfully saved to {filename}")
        else:
            print(f"No data available to save to {filename}")
    except Exception as e:
        print(f"An error occurred while saving to {filename}: {e}")

def save_to_json(data, filename):
    try:
        with open(filename, 'w') as f:
            json.dump(data, f, indent=4)
        print(f"Data successfully saved to {filename}")
    except Exception as e:
        print(f"An error occurred while saving to {filename}: {e}")


def get_and_save_data(subscription_id):
    resource_health_file = './data/resource_health.json'
    advisor_recommendations_file = './data/advisor_recommendations_raw.json'

    resource_health = list_resource_health(subscription_id)
    advisor_recommendations = list_advisor_recommendations(subscription_id)

    save_to_json(resource_health, resource_health_file)
    save_to_json(advisor_recommendations, advisor_recommendations_file)

