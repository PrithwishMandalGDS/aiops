import chromadb
import autogen
import pandas as pd
from autogen.agentchat.contrib.vectordb.chromadb import ChromaVectorDB
from autogen import config_list_from_json, Cache
from chromadb.utils import embedding_functions
from autogen.agentchat.contrib.retrieve_user_proxy_agent import RetrieveUserProxyAgent
from autogen.agentchat.contrib.retrieve_assistant_agent import RetrieveAssistantAgent
from autogen import AssistantAgent
import processinglibrary
import prompts.complexityprompt
import prompts.movegroupprompt
import prompts.rlaneprompt
import prompts.servermappingprompt
import prompts.surveyresponseprompt
import azureadvisor

# CHROMA_DB_AIOPS_INVENTORY_PATH="tmp/chromadb/aiops"

# CHROMA_COLLECTION="autogen-docs"

subscription_id = '181821eb-6bc1-41fa-bba6-5bfecf56c48f'

azureadvisor.get_and_save_data(subscription_id)

# aiops_chroma_client = chromadb.PersistentClient(path=CHROMA_DB_AIOPS_INVENTORY_PATH)

# AIOPS_collection = aiops_chroma_client.get_or_create_collection(name=CHROMA_COLLECTION)

# openai_ef = embedding_functions.OpenAIEmbeddingFunction(
#     model_name='text-embedding-ada-002',
#     api_key='dFndVNaSSIzadHvG0LFCkIA7GIuQaeiz',
#     api_base='https://eyq-incubator.asiapac.fabric.ey.com/eyq/as/api',
#     api_type='azure',
#     api_version='2023-05-15'
# )
# aiops_vector_db = ChromaVectorDB(path=CHROMA_DB_AIOPS_INVENTORY_PATH, embedding_function = openai_ef)
file_path = './data/advisor_recommendations_main_working.json'
df = pd.read_json(file_path)

def extract_provider(resource_id):
    parts = resource_id.split('/')
    
    try:
        provider_index = parts.index('providers') + 1
        provider = parts[provider_index]
    except ValueError:
        provider = None
    
    return provider

df['provider'] = df['id'].apply(extract_provider)
df.drop(['id', 'name', 'type', 'last_updated', 'resource_metadata', 'recommendation_type_id', "extended_properties"], axis=1, inplace=True)
df['short_description'] = df['short_description'].apply(lambda x: x['problem'] if isinstance(x, dict) and 'problem' in x else x)

columns = ['provider'] + [col for col in df.columns if col != 'provider']
df = df[columns]

df.rename(columns={
    'provider': 'PROVIDER',
    'category': 'CATEGORY',
    'impact': 'IMPACT',
    'impacted_field' : 'AZURE SERVICE NAME',
    'impacted_value': 'IMPACTED RESOURCES NAME',
    'short_description': 'PROBLEM DESCRIPTION'
}, inplace=True)

llm_config = {
    'config_list': config_list_from_json(
        env_or_file="OAI_CONFIG_LIST",
        filter_dict={
            "model": [
                "gpt-4-turbo",
            ]
        }
    ),
    'timeout': 600,
    "temperature": 0.9
    # 'cache_seed': 42
}

llm_config = {
    'config_list': config_list_from_json(
        env_or_file="OAI_CONFIG_LIST",
        filter_dict={
            "model": [
                "gpt-4-turbo",
            ]
        }
    ),
    'timeout': 600,
    "temperature": 0.9
    # 'cache_seed': 42
}

# aiops_retriever_config = {
#     "task": "qa",
#     "model": llm_config['config_list'][0]['model'],
#     "update_context": False,
#     "chunk_token_size": 5000,
#     "n_results": 1,
#     "docs_path": ["./data/advisor_recommendations.json"],
#     "get_or_create": True,
#     "overwrite": False,
#     "vector_db": aiops_vector_db,
#     "collection_name": CHROMA_COLLECTION,
#     "embedding_function": openai_ef
# }


#### App Survey Response Quality ###########
aiops_microsoft_advisor_agent_system_message = """
I'm going to give you a JSON file in the context. Then I'm going to ask you a question about it. evaluate the information in the form of a list of JSON objects. The provided context contains details of output generated from the Microsoft.Advisor/recommendations service of Azure Cloud.

 It provides a list of recommendations for a particular Azure subscription. Each JSON object consists of a recommendation about a particular cloud resource.

Here  the information captured as JSON attributes (in each JSON object) are:

1. resource_id inside the resource_metadata JSON attribute represents the resource for which the recommendation has been generated.
2.category represents how the recommendation will help with cloud strategy. Sample values are Performance, HighAvailability, OperationalExcellence, Cost.
3.impact represents the severity of the generated recommendation. Sample values are High, Medium, Low.
4.impacted_field represents the type of Azure Cloud resource.
5.impacted_value represents the name of the Azure Cloud resource.
6.roblem inside the short_description JSON attribute represents the actual problem.
7.solution inside the short_description JSON attribute represents the solution to the problem.
8.id represents the uniq identifier of the recommendation

Now consider all the above record as input to OpenAI llm model and ask for a customzied recommendation as per Azure Cloud best practice
**Provide the result in csv format**.
"""

#### App Survey Response Quality ###########
# aiops_microsoft_advisor_agent_system_message_1 = """
# AZUre Advisor has raised a high impact recommendation. Under category operational excellence. Impected field is 'MICROSOFT.NETWORK' in azure. Identified problem is 'Upgrade to the latest DRS rule set in Application Gateway WAF'. Please suggest a recommendation for this problem and give me required steps to implements. 
# """
 # When the values for resource_id field are same consider a record as duplicate and remove duplicates.

aiops_microsoft_advisor_question = "Your job is to list down all the records with impact as High and Generate response in an csv format with the column header - resource_id, category, impact, impacted_field as 'Azure Service Name', problem as 'Anomaly', solution as 'Recommendation', AI generated solution as 'Recommendation'  "

# def report_generation(html_content, output_file_name):    
#     startIndex = html_content.find('<table>')
#     endIndex = html_content.find('</table>')
#     sliced_table = html_content[startIndex:(endIndex + 8)]
#     processinglibrary.html_table_to_excel(sliced_table, output_file_name)   

######## Define agents #########
#agent for rag
# aiops_rag_proxy_agent = RetrieveUserProxyAgent(
#     name="aiops_rag_proxy_agent",
#     human_input_mode="NEVER",
#     llm_config=llm_config,
#     retrieve_config=aiops_retriever_config,
#     code_execution_config=False
# )



def get_recommendation(impact_level, provider_name, category, problem_statement):
    aiops_microsoft_advisor_agent_system_message_1 = f"""
    Azure Advisor has raised a {impact_level} impact recommendation, Under category {category}. Impacted field is '{provider_name}' in Azure. Identified problem is '{problem_statement}'. Please suggest a recommendation for this problem and give me the required steps to implement.
    """
    
    assistant = AssistantAgent(
        name="assistant",
        system_message=aiops_microsoft_advisor_agent_system_message_1,
        llm_config=llm_config
    )
    assistant.reset()
    
    userproxyagent = autogen.UserProxyAgent(
        name="userproxyagent",
        max_consecutive_auto_reply=1,
        human_input_mode="NEVER",
        code_execution_config=False
    )
    
    # Get the recommendation from the assistant
    aiops_recommendation_response = userproxyagent.initiate_chat(
        assistant,
        message="Please suggest a recommendation for this problem given the system message and provide the required steps to implement. No need to mention what Azure Advisor is"
    )
    
    csv_content_survey_response = next((item['content'] for item in aiops_recommendation_response.chat_history if 'assistant' in item['name']), None)

    return csv_content_survey_response

# Apply the recommendation function to the DataFrame
df['RECOMMENDATION'] = df.apply(
    lambda row: get_recommendation(row['CATEGORY'], row['IMPACT'], row['PROVIDER'], row['PROBLEM DESCRIPTION']),
    axis=1
)

# Print the DataFrame for verification
# print(df)

# Save the DataFrame to CSV
df.to_csv('./data/output_file_recom.csv', index=False)

# with Cache.disk() as cache:
#     #Servey Response Quality
#     aiops_recommendation_response = aiops_rag_proxy_agent.initiate_chat(
#         aiops_recomenndation_agent,
#         problem=aiops_microsoft_advisor_question,
#         n_results=1,
#         message=aiops_rag_proxy_agent.message_generator,
#         max_turns=1
#     )


# Survey Response Quality 
# print(aiops_recomendation_response)
# csv_name_content_survey_response = [item['name'] for item in aiops_recommendation_response.chat_history if 'aiops_recomenndation_agent' in item['name']]
# # report_generation(html_content_survey_response, "recomendation-report.xlsx")
# print("names", csv_name_content_survey_response)
# f1 = open("full_chat_history.txt", "w")
# f1.write(str(aiops_recommendation_response.chat_history))
# f1.close()

# # f = open("recomendation_high.csv", "w")
# csv_content_survey_response = next((item['content'] for item in aiops_recommendation_response.chat_history if 'assistant' in item['name']), None)
# f = open("recommendation_csv.txt", "w")
# f.write(csv_content_survey_response)
# f.close()

  # resource_id, category,  impacted_field , impacted_value, problem
# From the given json file source of context, evaluate the coverage of information in json object. The provided context contains details regarding the 

# Survey that was published to gather information for multiple applications for Discovery and Assessment purpose. 

# Your job is to provide the coverage of percentage of data in each column present in the context. If the value for any cell is empty, consider it as a blank value. 

# Generate response in an HTML tabular format with the columns - Column Name, Coverage Percentage, Missing Values Count (Application Names), Survey Response Quality. 
# According to coverage percentage, the 'Survey Response Quality' should be evaluated as below:
# 1. If the coverage percentage is between 80 - 100 percent, then the 'Survey Response Quality' is Green.
# 2. If the coverage percentage is between 60 - 80 percent, then the 'Survey Response Quality' is Amber.
# 3. If the coverage percentage is below 60 percent, then the 'Survey Response Quality' is Red.

# aiops_microsoft_advisor_question = "List down the unique records in the context provided. Also, mention in the brackets how many entries have been merged along with the names of the resource_id value for the resource_id column. "
# aiops_microsoft_advisor_question = "Your job is to list down resources present in the context and Generate response in an HTML tabular format with the columns - resource_id, category, impact, impacted_field, problem, solution. "

# ############ App Complexity ##########
# app_complexity_agent_system_message = """
# I'm going to give you a excel sheet in the context. Then I'm going to ask you a question about it. Document contains details about multiple applications. Details such as Application Name, Application Type, Operating System, Database Stack,No of Env,Application Dependency etc. are provided. Consider first row in the excel as the column name. Generate response in an HTML tabular format with the columns - Application Name, score_os,score_e,Application Dependency, max_val ,Complexity. Evaluate the complexity against each of the row based on the  value of max_val where max_val = (score_os + score_e + Application Dependency) .To get  the value for score_os , Application Dependency and score_e please follow the below rules and exexute it for each of the row:

# When the 'Operating System' in ["AS400"], set 5 to score_os.
# When the 'Operating System' in ["Ubuntu 16.04", "Ubuntu 14.04", "RHEL 8", "RHEL 9", "RHEL 7" "Ubuntu 20.04"], set 1 to score_os.
# When the value for 'No of Env' is equal to 1, , then set score_e = 1 .
# When the value for 'No of Env' is in  [2,3,4,5] , then set score_e = 3.
# When the value for 'No of Env' is greater than 5, then set score_e = 5.
# When the value for  'Application Dependency' is less than or equal to 5, then set score_d = 1 .
# When the value for 'Application Dependency' is  greater than or eqaul to 6  but less than or equal to 10, then set score_d = 3.
# When the value for 'Application Dependency' is greater than or equal to 11,then set score_d = 5.
# When max_val is less than or equal  to 5, assign  Complexity as 'Simple'.
# When max_val is greater than 5 but less than or equal to 10, assign  Complexity as 'Medium'.
# When max_val is  greater than or equal to 11, assign  Complexity as 'Complex'.

# **Provide the result in HTML table format without border attribute**.
# """

# complexity_question = "Provide Complexity  for all the applications in the provided context."

# ##### R-lane #############

# r_lane_agent_system_message = """
# I'm going to give you a excel sheet in the context. Then I'm going to ask you a question about it. Document contains details about multiple applications. Details such as Application Name, Application Type, Operating System, Database Stack, etc. are provided. Consider first row in the excel as the column name. Generate response in a HTML tabular format with the columns - Application Name, Infra R-Lane, Infra R-Lane Rationale, App R-Lane , App R-Lane Rationale, Final R-Lane.
# Evaluate Infra R-Lane and App R-Lane for each of the application based on the below criteria only. If any of the data is missing, consider the next criteria.

# Consider below criteria for evaluating Infra R-Lane:
# When 'Operating System' in ["AS400"], then set Infra R-Lane as Retire and skip the below  conditions.
# When 'Operating System' in ["Ubuntu 14.04", "Ubuntu 16.04", "RHEL 7", "RHEL 8"], then set Infra R-Lane as Replatform and skip the below  conditions.
# When 'Operating System' in ['RHEL 9', 'Ubuntu 20.04'], then set Infra R-Lane as Rehost and skip the below conditions.

# Consider below criteria for evaluating App R-Lane:
# When 'Database versions' in ["Oracle 10", "Oracle 12"] AND 'Application Tech Stack' in ["JDK 1.7"], then set App R-Lane as Refactor and skip the below  conditions.
# When 'Database versions' in ["Oracle 10"], then set App R-Lane as Refactor and skip the below  conditions.
# When 'Database versions' in ["Oracle 12"], then set App R-Lane as Replatform and skip the below  conditions.
# When 'Application Tech Stack' in ["JDK 1.7"], then set App R-Lane as Refactor and skip the below  conditions.
# When 'Database versions' in ["Oracle 19"] AND 'Application Tech Stack' in ["JAVA 8", "JAVA 11"], then set App R-Lane as Replatform and skip the below  conditions.
# When 'Database versions' in ["Oracle 19"] AND 'Application Tech Stack' in ["JAVA 17", "JDK 1.8"], then set App R-Lane as Rehost and skip the below  conditions.

# Provide rationale for Infra R-Lane and App R-Lane as below:
# If latest Operating System or Database version or Application tech stack is found in the document such as "Ubuntu 20.04" or "Oracle 19", rationale should be "Latest tech stack for lift and shift" along with the Tech Stack details for the latest tech stack only. But in case of Replatform R-Lane evaluation where latest tech stack might be present in the evaluation logic, the rationale should be "Tech Stack running EOS/EOL" along with the old Tech stack details only.
# If Operating System or Database version or Application tech stack running End of Life/End of Support is found in the document such as "Ubuntu 16.04" or "Java 11" which is not the oldest one, rationale should be "Tech Stack running EOS/EOL" along with the Tech Stack details.
# If oldest Operating System or Database version or Application tech stack is found in the document such as "RHEL 7" or "Oracle 10", rationale should be "Tech Stack needs significant upgrade resuting in code change" along with the Tech Stack details.

# Final R-Lane should be evaluated based on Infra R-Lane and App R-Lane. The criteria to evaluate the Final R-Lane is below. Once the criteria is met, do not evaluate the remaining conditions.
# 1. If any one of the Infra R-Lane or App R-Lane is Retire, then the Final R-Lane should be Retire and skip the below conditions.
# 2. If any one of the Infra R-Lane or App R-Lane is Refactor, then the Final R-Lane should be Refactor and skip the below conditions.
# 3. If any one of the Infra R-Lane or App R-Lane is Replatform, then the Final R-Lane should be Replatform and skip the below conditions.
# 4. If both the Infra R-Lane and App R-Lane are Rehost, then the Final R-Lane should be Rehost.

# **Provide the result in HTML table format without border attribute**.
# """
# rlane_question = "Provide R-Lane for all the applications in the provided context."

# ############# Server Mapping ###########

# server_mapping_agent_system_message = """
# From the given source of context, analyse the data in each column. The provided context contains details regarding the servers that are used across multiple applications for Discovery and Assessment purpose. Your job is to provide the ApplicationName to ServerName mapping.If one Application is using multiple Servers, please consolidate the details for all servers separated by comma.
# The response should be in a html tabular format with the column names as following: ApplicationName, ServerName, ServerCategory, ServerType. The criteria to evaluate ServerCategory and ServerType is explained below.

# ServerCategory should be evaluated as per the below criteria:
# 1. If the fourth character of the ServerName is 'P', then the ServerCategory should be Production.
# 2. If the fourth character of the ServerName is 'T', then the ServerCategory should be Test.
# 2. If the fourth character of the ServerName is 'D', then the ServerCategory should be Dev.

# ServerType should be evaluated as per the below criteria:
# 1. If the ServerName contains 'DB' in the exact letter sequence only, then the ServerType will be 'Database Server'.
# 2. If the ServerName doesn't contain the letter sequence 'DB', then the ServerType will be 'Application Server'.

# **Provide the result in HTML table format without border attribute**.
# """

# server_mapping_question = "Provide the details of all the servers based on the ApplicationName."

# ######### Move Group ########################
# move_group_agent_system_message = """
# You will receive a spreadsheet containing details about multiple applications. The document includes information such as Application Name, Inbound Apps, Outbound Apps, etc. The first row in the Excel sheet represents the column names. Your task is to generate a response in an HTML tabular format with the columns: Move Group, Application Grouping, and Rationale.

# Each row in the spreadsheet represents a separate application. Based on the criteria below, determine the move groups for all the applications. Categorize the move groups in a sequential way like MG1, MG2, etc. Execute each criterion for all rows. If any criterion is not satisfied, proceed to the next criterion; otherwise, skip the next criterion.

# Criteria 1:
# If an application does not contain both 'Inbound Apps' and 'Outbound Apps', then consider it as a standalone application. Group all standalone applications as part of the same 'Move Group' and mention all the 'Application Name' under the 'Application Grouping' column.

# Criteria 2:
# If an application's 'Inbound Apps' or 'Outbound Apps' match those of another 'Application Name' in the spreadsheet, group all matching applications as part of the same 'Move Group' and mention all the matching 'Application Name' under the 'Application Grouping' column.

# Sample input :
# Application Name, Inbound Apps, Outbound Apps
# Application1,,
# Application2,Application3,
# Application3,Application4,Application2
# Application4,,Application4
# Application5,,
# Application6,Application7,
# Application7,,Application6

# Samplea output:
# Move Group    Application Grouping                  Rationale
# MG1           Application1,Application5             Standalone apps
# MG2           Application2,Application3,Application4 Interdependent apps: Application2 is connected to Application3, Application3 is connected to Application4, and Application4 is connected to Application2
# MG3           Application6,Application7             Interdependent apps: Application6 is connected to Application7, and Application7 is connected to Application6

# If application name is present in Inbound apps or Outbound apps then those applications form a single movegroup.

# **Provide the result in HTML table format without border attribute**.
# """

# movegroup_question = "Provide movegroup for all the applications in the provided context."

####### File Processing Function ############
# def report_generation(html_content, output_file_name):    
#     startIndex = html_content.find('<table>')
#     endIndex = html_content.find('</table>')
#     sliced_table = html_content[startIndex:(endIndex + 8)]
#     processinglibrary.html_table_to_excel(sliced_table, output_file_name)   

# ######## Define agents #########
# #agent for rag
# aiops_rag_proxy_agent = RetrieveUserProxyAgent(
#     name="aiops_rag_proxy_agent",
#     human_input_mode="NEVER",
#     llm_config=llm_config,
#     retrieve_config=aiops_retriever_config,
#     code_execution_config=False
# )

# server_inventory_rag_proxy_agent = RetrieveUserProxyAgent(
#     name="server_inventory_rag_proxy_agent",
#     human_input_mode="NEVER",
#     llm_config=llm_config,
#     retrieve_config=server_inventory_retriever_config,
#     code_execution_config=False
# )

# aiops_recomenndation_agent = AssistantAgent(
#     name="aiops_recomenndation_agent",
#     system_message=aiops_microsoft_advisor_agent_system_message,
#     llm_config=llm_config
# )



# with Cache.disk() as cache:
#     #Servey Response Quality
#     aiops_recomendation_response = aiops_rag_proxy_agent.initiate_chat(
#         aiops_recomenndation_agent,
#         problem=aiops_microsoft_advisor_question,
#         n_results=1,
#         message=aiops_rag_proxy_agent.message_generator,
#         max_turns=5
#     )


# # Survey Response Quality 
# print("output", aiops_recomendation_response.chat_history)
# html_content_survey_response = next((item['content'] for item in aiops_recomendation_response.chat_history if 'html' in item['content']), None)
# report_generation(html_content_survey_response, "recomendation-report.xlsx")

# dna_app_complexity_agent = AssistantAgent(
#     name="dna_app_complexity_agent",
#     system_message=app_complexity_agent_system_message,
#     llm_config=llm_config
# )

# dna_rlane_agent = AssistantAgent(
#     name="dna_rlane_agent",
#     system_message=r_lane_agent_system_message,
#     llm_config=llm_config
# )

# dna_app_server_mapping_agent = AssistantAgent(
#     name="dna_app_server_mapping_agent",
#     system_message=server_mapping_agent_system_message,
#     llm_config=llm_config
# )

# dna_move_group_mapping_agent = AssistantAgent(
#     name="dna_move_group_mapping_agent",
#     system_message=move_group_agent_system_message,
#     llm_config=llm_config
# )

############## For testing only ##########

# #Servey Response Quality
# survey_quality_response = app_inventory_rag_proxy_agent.initiate_chat(
#         dna_app_survey_agent,
#         problem=survey_question,
#         n_results=1,
#         message=app_inventory_rag_proxy_agent.message_generator,
#         max_turns=5
#     )
    
#     #r-lane disposition
# rlane_response = app_inventory_rag_proxy_agent.initiate_chat(
#         dna_rlane_agent,
#         problem=rlane_question,
#         n_results=1,
#         message=app_inventory_rag_proxy_agent.message_generator,
#         max_turns=5
#     )
    
#     # Move Group
# move_group_response = app_inventory_rag_proxy_agent.initiate_chat(
#         dna_move_group_mapping_agent,
#         problem=movegroup_question,
#         n_results=1,
#         message=app_inventory_rag_proxy_agent.message_generator,
#         max_turns=5
#     )
    
#     # App Complexity
# app_complexity_response = app_inventory_rag_proxy_agent.initiate_chat(
#         dna_app_complexity_agent,
#         problem=complexity_question,
#         n_results=1,
#         message=app_inventory_rag_proxy_agent.message_generator,
#         max_turns=5
#     )
    
#     # Server Mapping
# server_mapping_response = server_inventory_rag_proxy_agent.initiate_chat(
#         dna_app_server_mapping_agent,
#         problem=server_mapping_question,
#         n_results=1,
#         message=server_inventory_rag_proxy_agent.message_generator,
#         max_turns=5
#     )    
    
    # #r-lane disposition
    # rlane_response = app_inventory_rag_proxy_agent.initiate_chat(
    #     dna_rlane_agent,
    #     problem=rlane_question,
    #     n_results=1,
    #     message=app_inventory_rag_proxy_agent.message_generator,
    #     max_turns=5
    # )
    
    # # Move Group
    # move_group_response = app_inventory_rag_proxy_agent.initiate_chat(
    #     dna_move_group_mapping_agent,
    #     problem=movegroup_question,
    #     n_results=1,
    #     message=app_inventory_rag_proxy_agent.message_generator,
    #     max_turns=5
    # )
    
    # # App Complexity
    # app_complexity_response = app_inventory_rag_proxy_agent.initiate_chat(
    #     dna_app_complexity_agent,
    #     problem=complexity_question,
    #     n_results=1,
    #     message=app_inventory_rag_proxy_agent.message_generator,
    #     max_turns=5
    # )
    
    # # Server Mapping
    # server_mapping_response = server_inventory_rag_proxy_agent.initiate_chat(
    #     dna_app_server_mapping_agent,
    #     problem=server_mapping_question,
    #     n_results=1,
    #     message=server_inventory_rag_proxy_agent.message_generator,
    #     max_turns=5
    # )    

#### Output Report Generation ###########  


# # rlane Disposition
# html_content_rlane_disposition = next((item['content'] for item in rlane_response.chat_history if 'html' in item['content']), None)
# report_generation(html_content_rlane_disposition, prompts.rlaneprompt.rlane_output_spreadsheet_agent)

# # app-complexity
# html_content_app_complexity_disposition = next((item['content'] for item in app_complexity_response.chat_history if 'html' in item['content']), None)
# report_generation(html_content_app_complexity_disposition, prompts.complexityprompt.complexity_output_spreadsheet_agent)
 
# # app server mapping
# html_content_app_server_mapping_disposition = next((item['content'] for item in server_mapping_response.chat_history if 'html' in item['content']), None)
# report_generation(html_content_app_server_mapping_disposition, prompts.servermappingprompt.server_mapping_output_spreadsheet_agent)   

# # move-group
# html_content_move_group_disposition = next((item['content'] for item in move_group_response.chat_history if 'html' in item['content']), None)
# report_generation(html_content_move_group_disposition, prompts.movegroupprompt.movegroup_output_spreadsheet_agent)